<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Dashboard</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />

    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/animate.min.css')); ?>" rel="stylesheet">
    
    <link href="<?php echo e(asset('assets/css/paper-dashboard.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('assets/css/demo.css')); ?>" rel="stylesheet">

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('assets/css/themify-icons.css')); ?>" rel="stylesheet">

</head>
<body>

<div class="wrapper">
    <div class="sidebar" data-background-color="white" data-active-color="danger">


    	<div class="sidebar-wrapper">
            <div class="logo">
                    ADMIN DASBOARD
            </div>

            <ul class="nav">
                    <li>
                        <a href="">
                            <i class="ti-panel"></i>
                            <p>Region Data</p>
                        </a>
                    </li>
                    <li class="active">
                        <a href="">
                            <i class="ti-user"></i>
                            <p>User Profile</p>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <i class="ti-view-list-alt"></i>
                            <p>Table List</p>
                        </a>
                    </li>

                </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar bar1"></span>
                        <span class="icon-bar bar2"></span>
                        <span class="icon-bar bar3"></span>
                    </button>
                    <a class="navbar-brand" href="#">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        
                        <li class="dropdown">
                              <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="ti-bell"></i>
                                    <p class="notification">5</p>
									<p>Notifications</p>
									<b class="caret"></b>
                              </a>
                              <ul class="dropdown-menu">
                                    <li><a href="#">Donor Darah Terverifikasi</a></li>
                                    <li><a href="#">Imuniasasi Terverifikasi</a></li>
                                    <li><a href="#">Asuransi Terverifikasi</a></li>
                              </ul>
                        </li>
						
                    </ul>

                </div>
            </div>
        </nav>


        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 margin-tb">
                        <div class="pull-left">
                            <h2><?php echo e($regionals->regionid); ?></h2>
                        </div>  
                        <div class="pull-right">
                            <button class="btn btn-primary" data-toggle="modal" data-target="#inputregion">Input Data</button>
                        </div>
                    </div>
                </div>

                <?php if($message=Session::get('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e($message); ?></p>
                    </div>
                <?php endif; ?>
                
                <div class="row">
                    <div class="col-md-12 order-first mt-2">
                        <div class="table-responsive">
                            <table id=tableadmin class="table table-md table-bordered">
                                <tr style="background-color:#EB5E28;color:white;">
                                    <th class="font-weight-bold" style="text-align: center;">BuildingID</th>
                                    <th class="font-weight-bold" style="text-align: center;">Nama Pemilik</th>
                                    <th class="font-weight-bold" style="text-align: center;">Fungsi Bangunan</th>
                                    <th class="font-weight-bold" style="text-align: center;">Status Bangunan</th>
                                    <th class="font-weight-bold" style="text-align: center;">Status Tanah</th>
                                    <th class="font-weight-bold" style="text-align: center;">Action</th>
                                </tr>
                                <?php if(count($regionals)): ?>
                                <?php $__currentLoopData = $regionals->buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="text-align:center;">
                                    <td style="text-align: center;"><?php echo e($building->buildingid); ?></td>
                                    <td style="text-align: center;"><?php echo e($building->namapemilik); ?></td>
                                    <td style="text-align: center;"><?php echo e($building->fungsibangunan); ?></td>
                                    <td style="text-align: center;"><?php echo e($building->statusbangunan); ?></td>
                                    <td style="text-align: center;"><?php echo e($building->statustanah); ?></td>
                                    <td>
                                       
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <tr>
                                    <td allign="center" colspan="6">
                                    Empty Data!! Have a nice day :)
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </table>
                        </div> 
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>


</body>

    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap-checkbox-radio.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/chartist.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap-notify.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/paper-dashboard.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/demo.js')); ?>"></script>

</html>
